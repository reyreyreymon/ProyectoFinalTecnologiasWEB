import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preguntasf',
  templateUrl: './preguntasf.component.html',
  styleUrls: ['./preguntasf.component.css']
})
export class PreguntasfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
