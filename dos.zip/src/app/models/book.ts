export interface BookInterface{
    titulo?: string;
    idioma?: string;
    descripcion?: string;
    portada?: string;
    precio?: string;
    oferta?: string;
    id?: string;
}